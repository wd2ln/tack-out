package destory;

import java.util.Scanner;

public class Test3 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int x = input.nextInt();
        boolean result = isPalindrome(x);
        System.out.println(result);
        input.close();
    }

    public static boolean isPalindrome(int x) {
        int num = x;
        int n = 0;
        // 获取倒叙
        while (x != 0) {
            n = n * 10 + x % 10;
            x = x / 10;
        }
        // 如果正序等于倒叙则是回文数
        if (n == num) {
            return true;
        }
        return false;
    }
}
