package destory;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import java.util.Date;

public class Test2 {
    public static void main(String[] args) {
        User tom = new User(4, "tom", "123",new Date());
        //json对象转字符串
        String s = JSON.toJSONString(tom);
        System.out.println(s instanceof String);
        System.out.println(s );
        //字符串转java对象
        User parse = JSON.parseObject(s,User.class);
        System.out.println(parse);
        // 将Json字符串转为Json对象
        JSONObject jsonObject = JSON.parseObject(s);
        // 根据键获取对应的值
        System.out.println(jsonObject.getString("id"));
    }
}
