package student1;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/mhcx")
public class Mhcx extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String name = req.getParameter("selectGo");
        String sex = req.getParameter("sex");
        HttpSession session = req.getSession(false);
        session.setAttribute("sname",name);
        session.setAttribute("ssex",sex);
        //session.setAttribute("mh","模糊查询");
        //获取数据库连接。。。。
        SelStudents selStudents = new SelStudents(sex,name);
        //准备sql及参数
            selStudents.sex=sex;
            selStudents.name=name;
        // 获取当前页
        String param = req.getParameter("pageNo");
        // 如果没有传递当前页，默认就是第一页
        int pageNo=1;
        if (param !=null) {
            //System.out.println(param+"=====");
            pageNo=Integer.parseInt(param);

        }
        // 规定好每页显示多少条数据
        int pageSize=6;

        SelStudents studentService = new SelStudents(sex,name);
        PageInfo<Student> pageInfo = studentService.getPageInfo(pageNo, pageSize);
        req.setAttribute("pageInfo2",pageInfo);
        req.getRequestDispatcher("page2.jsp").forward(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}
