package student1;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/page")
public class QueryStudent extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 获取当前页
        String param = req.getParameter("pageNo");
        // 如果没有传递当前页，默认就是第一页
        int pageNo=1;
        if (param !=null) {
            pageNo=Integer.parseInt(param);

        }
        // 规定好每页显示多少条数据
        int pageSize=6;

        StudentService studentService = new StudentService();
        PageInfo<Student> pageInfo = studentService.getPageInfo(pageNo, pageSize);
        req.setAttribute("pageInfo",pageInfo);
        req.getRequestDispatcher("page1.jsp").forward(req,resp);
    }
}
