package student1;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import util.JdbcUtilsOnDruid;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

@WebServlet("/zc1")
public class Zc extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //获取前端数据
        String username = req.getParameter("username");
        String pwd = req.getParameter("password");
        System.out.println("获取用户名密码成功");
        //创建数据库连接
        Connection connection = JdbcUtilsOnDruid.getConnection();
        Connection connection1 = JdbcUtilsOnDruid.getConnection();
        Connection connection2 = JdbcUtilsOnDruid.getConnection();
        Connection connection3 = JdbcUtilsOnDruid.getConnection();
        QueryRunner queryRunner = new QueryRunner();
        //sql语句
        String sql = "insert into user(username,password) values (?,?);";
        Object[] parmes = {username, pwd};
        int aff = 0;
        try {
            aff = queryRunner.update(connection, sql, parmes);
            System.out.println("创建账户成功");
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JdbcUtilsOnDruid.close(connection);
        }
        System.out.println(aff);
        if (aff > 0) {
            //给用户创建默认信息
            String sql1 = "insert into user_info values();";
            try {
                queryRunner.update(connection1, sql1);
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                JdbcUtilsOnDruid.close(connection1);
            }
            //获取用户信息表刚创建的id
            String sql3 = "select * from user_info ORDER BY id desc limit 0,1;";
            UserInfo usid = null;
            try {
                usid = queryRunner.query(connection2, sql3, new BeanHandler<>(UserInfo.class));
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                JdbcUtilsOnDruid.close(connection2);
            }
            System.out.println("从数据库获取的id为： " + usid);
            String sql2 = "insert into user_re_user_info(user_id,user_info_id)" +
                    " select u.id,u1.id " +
                    "from user u inner join " +
                    "user_info u1 on u.username=? and u1.id=?;";
            Object[] par = {username, usid.getId()};
            try {
                queryRunner.update(connection3, sql2, par);
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                JdbcUtilsOnDruid.close(connection3);
            }
            resp.sendRedirect("login.jsp");
        }
    }
}
