package student1;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import util.JdbcUtilsOnDruid;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class SelStudents{
    private final QueryRunner queryRunner = new QueryRunner();
    private final Connection connection = JdbcUtilsOnDruid.getConnection();
    public String sex;
    public String name;
    public String sql;

    public SelStudents(String sex, String name) {
        this.sex = sex;
        this.name = name;
    }
    //获取数据总量
    public int getTotalCount() {
        //准备sql及参数
        if(sex!=null&&name!=null&&name!=""&&sex!=""){
            sql="select * from student where name like '%"+name+"%' and gender='"+sex+"';";
        }else if(sex!=null&&sex!=""){
            sql="select * from student where gender='"+sex+"';";
        }else if(name!=null&&name!=""){
            sql="select * from student where name like '%"+name+"%';";
        }else {
            sql="";
        }
        List<Student> list = null;
        try {
            list=queryRunner.query(connection,sql,new BeanListHandler<>(Student.class));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        /*System.out.println(sql);
        System.out.println(sex);
        System.out.println(name);
        System.out.println("获取数据总量：======"+list.size());*/
        if (list == null) {
            return 0;
        }
        return list.size();
    }
    //获取每页中的数据
    public List<Student> getListByPage(int start, int pageSize) {
        System.out.println("start= "+start);
        //准备sql及参数
        if(sex!=null&&name!=null&&name!=""&&sex!=""){
            sql="select * from student where name like '%"+name+"%' and gender='"+sex+"' limit ?,?;";
        }else if(sex!=null&&sex!=""){
            sql="select * from student where gender='"+sex+"' limit ?,?;";
        }else if(name!=null&&sex!=""){
            sql="select * from student where name like '%"+name+"%' limit ?,?;";
        }else {
            sql="";
        }
        List<Student> list = null;
        try {
            list=queryRunner.query(connection,sql,new BeanListHandler<>(Student.class),start,pageSize);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public PageInfo<Student> getPageInfo(int pageNo, int pageSize) {
       /* System.out.println("性别："+sex);
        System.out.println("名字："+name);
        System.out.println("sql：  "+sql);*/
        // 获取总数据量
        int totalCount=getTotalCount();
        //System.out.println("获取到模糊查询数据总量："+totalCount);
        //System.out.println("sql：  "+sql);
        // 获取每页的开头，用于查询数据库
        int start=(pageNo-1)*pageSize;
        // 获取每页中的所有内容
        List<Student> list=getListByPage(start,pageSize);
        //System.out.println("每页有："+list.size());
        JdbcUtilsOnDruid.close(connection);
        // 获取分页信息对象
        return new PageInfo<>(totalCount,pageSize,pageNo,list);
    }
}
