package student1;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
/**
 * 通过过滤器设置字符编码
 */
@WebFilter(urlPatterns = "/*", initParams = {@WebInitParam(name = "characterEncoding", value = "utf-8"),
        @WebInitParam(name = "contentType", value = "text/html;charset=utf8")})
public class EncodingFilter implements Filter {
    // 声明编码集和文本内容
    private String characterEncoding;
    private String contentType;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // 通过过滤器配置对象中的初始化参数获取编码集和文本内容
        characterEncoding = filterConfig.getInitParameter("characterEncoding");
        contentType = filterConfig.getInitParameter("contentType");

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        // 将请求和响应对象强转为支持HTTP协议的请求和响应对象
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;
        // 设置请求和响应对象的编码集
        response.setContentType(contentType);
        request.setCharacterEncoding(characterEncoding);
        //放行
        filterChain.doFilter(servletRequest, servletResponse);
    }

    @Override
    public void destroy() {

    }
}
