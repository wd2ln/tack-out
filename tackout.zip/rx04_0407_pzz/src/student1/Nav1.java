package student1;

import com.fasterxml.jackson.databind.ObjectMapper;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/nav1")
public class Nav1 extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //获取前端数据
        String data = req.getParameter("selectGo");
        String op = req.getParameter("op");
        if (op.equals("菜品类型")){
            op="";
        }
        String sql = "select nm.id,nm.name 'foodName',n.name 'className'" +
                "from nav_menu n INNER JOIN nav_menu_item nm " +
                "INNER JOIN nav_menu_re_item na on" +
                " na.menu_id=n.id and na.item_id=nm.id";
        if(data!=""&&op!=""){
            sql+=" where nm.name like '%"+data+"%' and n.name='"+op+"'";
            // 获取当前页
            String param = req.getParameter("pageNo");
            // 如果没有传递当前页，默认就是第一页
            int pageNo=1;
            if (param !=null) {
                pageNo=Integer.parseInt(param);

            }
            // 规定好每页显示多少条数据
            int pageSize=6;

            NavService studentService = new NavService(sql);
            PageInfo<NavInfo1> pageInfo = studentService.getPageInfo(pageNo, pageSize);
            req.setAttribute("pageNav1",pageInfo);

        }else if(data!=""){
            sql+=" where nm.name like '%"+data+"%'";
            // 获取当前页
            String param = req.getParameter("pageNo");
            // 如果没有传递当前页，默认就是第一页
            int pageNo=1;
            if (param !=null) {
                pageNo=Integer.parseInt(param);

            }
            // 规定好每页显示多少条数据
            int pageSize=6;

            NavService studentService = new NavService(sql);
            PageInfo<NavInfo1> pageInfo = studentService.getPageInfo(pageNo, pageSize);
            req.setAttribute("pageNav1",pageInfo);
        }else if(op!=""){
            sql+=" where n.name='"+op+"'";
            // 获取当前页
            String param = req.getParameter("pageNo");
            // 如果没有传递当前页，默认就是第一页
            int pageNo=1;
            if (param !=null) {
                pageNo=Integer.parseInt(param);

            }
            // 规定好每页显示多少条数据
            int pageSize=6;

            NavService studentService = new NavService(sql);
            PageInfo<NavInfo1> pageInfo = studentService.getPageInfo(pageNo, pageSize);
            req.setAttribute("pageNav1",pageInfo);
        }else {

        }
        HttpSession session = req.getSession(false);
        session.setAttribute("foodo",data);
        session.setAttribute("classo",op);
        req.getRequestDispatcher("nav1.jsp").forward(req,resp);
    }
}
