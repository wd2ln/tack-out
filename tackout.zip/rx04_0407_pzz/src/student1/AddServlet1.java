package student1;


import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.dbutils.QueryRunner;
import util.JdbcUtilsOnDruid;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;

/**
 * 添加学生信息
 */
@WebServlet("/add")
public class AddServlet1 extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {


        // 获取存储请求参数的map
        Map<String, String[]> map = req.getParameterMap();

        // 声明实体类对象
        Student student = new Student();

        try {
            // 将map中的数据存储到学生对象中
            BeanUtils.populate(student, map);
        } catch (IllegalAccessException | InvocationTargetException e) {
            e.printStackTrace();
        }

        // 获取DbUtils核心类对象
        QueryRunner queryRunner = new QueryRunner();

        // 获取通过c3p0获取数据库连接
        Connection connection = JdbcUtilsOnDruid.getConnection();

        // 准备SQL语句
        String sql = "insert into student(name, age, gender, info) values(?, ?, ?, ?)";

        // 提取受影响的行数
        int affectedRows = 0;

        try {
            // 执行SQL语句并获取受影响的行数
            affectedRows = queryRunner.update(connection, sql, student.getName(), student.getAge(), student.getGender(), student.getInfo());
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JdbcUtilsOnDruid.close(connection);
        }

        // 判断受影响的行数是否大于0
        if (affectedRows > 0) {
            req.setAttribute("message", "添加成功");
            // 重定向至添加成功页
            req.getRequestDispatcher("page").forward(req, resp);
        } else {
            req.setAttribute("message", "添加失败");

            req.setAttribute("flag", true);
            // 重定向至添加失败页
            req.getRequestDispatcher("fail.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}
