package student1;


import org.apache.commons.dbutils.QueryRunner;
import util.JdbcUtilsOnDruid;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * 删除学生信息
 */
@WebServlet("/delete1")
public class DeleteServlet1 extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Connection connection=null;
        /*StringBuffer requestURL = req.getRequestURL();
        System.out.println(requestURL);*/
        try {
            int id=-1;
            // 获取前端请求的参数
            String getId = req.getParameter("id");
            // 连接数据库
            // 获取核心类对象
            QueryRunner queryRunner = new QueryRunner();

            // 获取数据库连接
             connection = JdbcUtilsOnDruid.getConnection();

            // 准备SQL语句
            String sql = "delete na,nr from nav_menu_item na" +
                    " INNER JOIN nav_menu_re_item nr on " +
                    "na.id=nr.item_id and na.id=?;";
            int affectedRows=0;
            //多条删除记录
            int counts=0;
            //判断是批量删除还是单个
            if (getId.length()>1){
                String[] str=getId.split(",");
                for (String s : str) {
                    id= Integer.parseInt(s);
                    // 准备参数
                    Object[] params = {id};
                    // 执行SQL语句
                     affectedRows = queryRunner.update(connection, sql, params);
                    if(affectedRows>0){
                        counts++;
                    }
                }
            }else {
                // 自动拆箱
                id = Integer.parseInt(getId);
                // 准备参数
                Object[] params = {id};
                // 执行SQL语句
                 affectedRows = queryRunner.update(connection, sql, params);

            }


            System.out.println(affectedRows);
            // 判断是否删除成功
            if (affectedRows ==2||affectedRows==(counts*2)) {

                req.setAttribute("message", "删除成功");
                // 删除成功
                req.getRequestDispatcher("pageNav1").forward(req, resp);
            } else {
                req.setAttribute("message", "删除失败");

                // 删除失败
                req.getRequestDispatcher("fail.jsp").forward(req, resp);
            }
        } catch (UnsupportedEncodingException | SQLException e) {
            e.printStackTrace();
        }finally {
            JdbcUtilsOnDruid.close(connection);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}