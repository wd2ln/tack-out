package student1;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
/**
 * 退出登录
 */
@WebServlet("/logout")
public class Logout extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        //判断用户是否记住密码
        String password =(String) session.getAttribute("password");
        String username =(String) session.getAttribute("username");
        if (session != null) {
            session.removeAttribute("username");
            session.invalidate();
        }
        Cookie cookie = new Cookie("JSESSIONID", "");
        cookie.setMaxAge(0);
        resp.addCookie(cookie);
        if (password!=null){
            HttpSession session1 = req.getSession();
            session1.setAttribute("username",username);
            session1.setAttribute("password",password);
            session1.setMaxInactiveInterval(20);
        }
        resp.sendRedirect("index.jsp");
    }
}
