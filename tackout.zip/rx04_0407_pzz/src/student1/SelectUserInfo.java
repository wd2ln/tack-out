package student1;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import util.JdbcUtilsOnDruid;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

@WebServlet("/sui")
public class SelectUserInfo extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //获取前端数据
        String lt = req.getParameter("lt");
        System.out.println("**************");
        System.out.println(lt);
        //从数据库拿取用户信息
        HttpSession session = req.getSession(false);
        QueryRunner queryRunner = new QueryRunner();
        Connection connection = JdbcUtilsOnDruid.getConnection();
        //String sql="select * from user_info,user where user.username=?;";
        String sql = "select * from user_info u" +
                " where u.id=(select u1.user_info_id from " +
                "user_re_user_info u1 inner join user on" +
                " u1.user_id=user.id and user.username=?); ";
        UserInfo userInfo = null;
        Object[] parmes = {session.getAttribute("username")};
        try {
            userInfo = queryRunner.query(connection, sql, new BeanHandler<>(UserInfo.class), parmes);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JdbcUtilsOnDruid.close(connection);
        }
        //拿到用户信息
        if (userInfo != null) {
            session.setAttribute("userInfo", userInfo);
            if (lt!=null) {
                resp.sendRedirect("file_up.jsp");
            }else {
                    resp.sendRedirect("pageNav1");
            }
            //System.out.println("用户信息拿取成功");
        } else {
           // System.out.println("用户信息拿取失败");
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }
}
