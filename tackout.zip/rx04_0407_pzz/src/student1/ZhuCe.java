package student1;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import util.JdbcUtilsOnDruid;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * 注册用户页面
 */
@WebServlet("/zhuce1")
public class ZhuCe extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //获取前端数据
        String username = req.getParameter("username");
        System.out.println(username);
        //创建数据库连接
        Connection connection=JdbcUtilsOnDruid.getConnection();
        QueryRunner queryRunner=new QueryRunner();
        //sql语句
        String sql="select * from user where username=?;";
        Object[] parmes={username};
        User user=null;
        try {
            user=queryRunner.query(connection,sql,new BeanHandler<>(User.class),parmes);
            } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JdbcUtilsOnDruid.close(connection);
        }
        resp.getWriter().print(user == null);
    }
    }

