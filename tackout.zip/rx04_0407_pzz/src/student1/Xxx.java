package student1;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.dbutils.QueryRunner;
import util.JdbcUtilsOnDruid;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

@WebServlet("/xxx")
public class Xxx extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //获取前端值
        String nc = req.getParameter("nc");
        String qm = req.getParameter("qm");
        String csrf = req.getParameter("date1");
        String sex = req.getParameter("sex1");
        String yhm = req.getParameter("yhm1");
        System.out.println(csrf);
        //ajax测试失败
       /* String data = req.getParameter("data");
        ObjectMapper mapper = new ObjectMapper();
        System.out.println(data);
        System.out.println(mapper);
        UserInfo userInfo1 = mapper.readValue(data, UserInfo.class);
        System.out.println(userInfo1);*/
        //连接数据库
        QueryRunner queryRunner = new QueryRunner();
        Connection connection = JdbcUtilsOnDruid.getConnection();
        String sql="UPDATE user_info u1,user_re_user_info u2, " +
                "user u3 set u1.nickname=?,u1.signature=?,u1.gender=?," +
                "u1.birthday=? where " +
                "u2.user_info_id=u1.id and u2.user_id=u3.id " +
                "and u3.username=?;";
        Object[] parmes={nc,qm,sex,csrf,yhm};
        //Object[] parmes={userInfo1.getNickname(),userInfo1.getSignature(),userInfo1.getGender(),userInfo1.getBirthday(),userInfo1.getYhm()};
        int aff=0;
        try {
            aff=queryRunner.update(connection,sql,parmes);
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JdbcUtilsOnDruid.close(connection);
        }
        if(aff>0){
            System.out.println("用户信息更改成功");
            resp.sendRedirect("sui");
        }else {
            System.out.println("用户信息更改失败");
            resp.sendRedirect("sui");
        }
    }
}
