package student1;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import util.JdbcUtilsOnDruid;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.jsp.PageContext;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * 用户名登陆验证
 */
@WebServlet("/yanzheng")
public class YanZheng extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
       //获取前端数据
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        System.out.println("获取用户名密码成功");
        //验证登陆
        if (password == null||username==null) {
            resp.sendRedirect("login.jsp");
        }else {
            //从数据库找该用户
            // 获取核心类对象
            QueryRunner queryRunner = new QueryRunner();

            // 获取连接
            Connection connection = JdbcUtilsOnDruid.getConnection();

            // 准备SQL语句
            String sql = "select * from user where username = ? and password=?";
            Object[] parmes={username,password};
            User user=null;
            try {
                 user = queryRunner.query(connection, sql, new BeanHandler<>(User.class),parmes);
                if (user != null) {
                    System.out.println("登陆成功");
                    //获取用户登录是否记住密码
                    String chx = req.getParameter("ckx");
                    System.out.println("是否记住密码:   "+chx);
                    System.out.println(chx!=null);
                    //创建session
                    HttpSession session = req.getSession(true);
                    session.setAttribute("username",username);
                    //创建cookie
                    Cookie cookie = new Cookie("JSESSIONID", session.getId());
                    cookie.setMaxAge(60*60);
                    if (chx!=null&&chx.equals("on")){
                        session.setAttribute("password",password);
                    }
                    session.setMaxInactiveInterval(60*60);
                    resp.addCookie(cookie);
                    req.getRequestDispatcher("sui").forward(req,resp);
                }else {
                    resp.sendRedirect("login.jsp");
                    System.out.println("登陆失败");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }finally {
                JdbcUtilsOnDruid.close(connection);
            }
        }

    }
}
