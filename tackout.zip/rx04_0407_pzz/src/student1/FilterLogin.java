package student1;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * 自动登录过滤器
 */
@WebFilter("/*")
public class FilterLogin implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        // 将请求和响应对象强转为支持HTTP协议的对象
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;
        // 通过请求对象获取session对象，注意参数要用false
        HttpSession session = request.getSession(false);
        // 获取请求URI
        String uri = request.getRequestURI();
        //System.out.println(uri);
        // 判断请求URI是否以指定登录路径结尾
        if (uri.endsWith("/index.jsp")||uri.endsWith("/login.jsp")
                ||uri.endsWith("/yanzheng")||uri.endsWith("/code")||
                uri.endsWith("/zhuce.jsp")||uri.endsWith("/zhuce1")
        ||uri.endsWith("/jquery-1.8.3.min.js")
                ||uri.endsWith("yzm.jsp")||uri.endsWith("zc1")||uri.endsWith("cod")) {
            // 放行
            //System.out.println("uri过关");
            filterChain.doFilter(request, response);
        }else if(session==null){
            response.sendRedirect("login.jsp");
        }else if(session.getAttribute("username")!=null){
            // 放行
            filterChain.doFilter(request, response);
            //System.out.println("session过关");
        }else {
            // 跳转至登录页面
            response.sendRedirect("login.jsp");
        }
    }

    @Override
    public void destroy() {

    }
}
