package student1;

import org.apache.commons.dbutils.QueryRunner;
import util.JdbcUtilsOnDruid;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

@WebServlet("/fileUp")
// 声明文件上传所需要的注解
@MultipartConfig
public class FileUp extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 从前端获取name属性对应的文件
        Part file = req.getPart("file");
        // 获取对应的请求头
        String header = file.getHeader("Content-Disposition");
        //获取文件名
        String fileName = header.substring(header.indexOf("filename=\"") + 10, header.lastIndexOf("\""));
        System.out.println(fileName);
        // 把文件写入到指定路径
        file.write("/home/pzz/下载/apache-tomcat-10.0.13/webapps/images/"+fileName);
        //更新数据库
        QueryRunner queryRunner = new QueryRunner();
        Connection connection = JdbcUtilsOnDruid.getConnection();
        String sql="update user_info set face=? where id=?";
        String user_info_id = req.getParameter("user_info_id");
        Object[] parmes={"http://localhost:8888/images/"+fileName,user_info_id};
        try {
            queryRunner.update(connection,sql,parmes);
            //重定向到个人信息页面
            resp.sendRedirect("sui");
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JdbcUtilsOnDruid.close(connection);
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }
}
