package student1;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import util.JdbcUtilsOnDruid;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class StudentService {
    private final QueryRunner queryRunner = new QueryRunner();
    private final Connection connection = JdbcUtilsOnDruid.getConnection();

    // 获取总数据量
    public int getTotalCount() {
        String sql = "select * from student;";
        List<Student> list = null;
        try {
            list=queryRunner.query(connection,sql,new BeanListHandler<>(Student.class));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        if (list == null) {
            return 0;
        }
        //System.out.println("list is "+list.size());
        return list.size();
    }
    //获取每页中的数据
    public List<Student> getListByPage(int start, int pageSize){
        String sql = "select * from student limit ?,?;";
        List<Student> list = null;
        try {
            list=queryRunner.query(connection,sql,new BeanListHandler<>(Student.class),start,pageSize);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    // 获取分页信息对象
    public PageInfo<Student> getPageInfo(int pageNo, int pageSize){
        // 获取总数据量
        int totalCount=getTotalCount();
        // 获取每页的开头，用于查询数据库
        int start=(pageNo-1)*pageSize;
        // 获取每页中的所有内容
        List<Student> list=getListByPage(start,pageSize);
        JdbcUtilsOnDruid.close(connection);
        // 获取分页信息对象
        return new PageInfo<>(totalCount,pageSize,pageNo,list);
    }
}
