package student1;


import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import util.JdbcUtilsOnDruid;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * 修改nav1操作
 */
@WebServlet("/select1")
public class SelectServletNav1 extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException, IOException {


        // 从前端获取请求参数
        String getId = req.getParameter("id");

        // 转为int类型
        int id = Integer.parseInt(getId);

        // 获取核心类对象
        QueryRunner queryRunner = new QueryRunner();

        // 获取连接
        Connection connection = JdbcUtilsOnDruid.getConnection();

        // 准备SQL语句
        String sql = "select nm.id,nm.name 'foodName',n.name 'className'" +
                "from nav_menu n INNER JOIN " +
                "nav_menu_item nm INNER JOIN " +
                "nav_menu_re_item na on" +
                " na.menu_id=n.id and na.item_id=nm.id " +
                "where nm.id=?;";

        // 提取学生对象
        NavInfo1 student = null;

        // 执行SQL语句
        try {
            student = queryRunner.query(connection, sql, new BeanHandler<NavInfo1>(NavInfo1.class), id);
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JdbcUtilsOnDruid.close(connection);
        }

        // 判断当前学生是否为空
        if (student == null) {
            req.setAttribute("message", "查无此人");

            // 删除失败
            req.getRequestDispatcher("fail.jsp").forward(req, resp);

        } else {
            req.setAttribute("student1", student);

            // 删除失败
            req.getRequestDispatcher("update1.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }
}
