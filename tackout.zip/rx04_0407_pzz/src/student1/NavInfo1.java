package student1;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class NavInfo1 {
    private Integer id;
    private String foodName;
    private String className;
}
