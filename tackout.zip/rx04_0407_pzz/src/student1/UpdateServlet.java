package student1;


import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.dbutils.QueryRunner;
import util.JdbcUtilsOnDruid;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;
/**
 * 修改学生信息
 */
@WebServlet("/update")
public class UpdateServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Connection connection=null;
        try {


            // 获取请求参数
            Map<String, String[]> map = req.getParameterMap();

            // 准备实体类对象
            Student student = new Student();

            // 将map中的参数封装到实体类对象中
            BeanUtils.populate(student, map);

            // 获取核心类对象
            QueryRunner queryRunner = new QueryRunner();

            // 获取数据库连接
             connection = JdbcUtilsOnDruid.getConnection();

            // 准备SQL语句
            String sql = "update student set name = ?, age = ?, gender = ?, info = ? where id = ?";

            // 执行SQL语句
            int affectedRows = queryRunner.update(connection, sql, student.getName(), student.getAge(), student.getGender(), student.getInfo(),
                    student.getId());

            // 判断是否修改成功
            if (affectedRows > 0) {

                req.setAttribute("message", "修改成功");
                // 删除成功
                req.getRequestDispatcher("page").forward(req, resp);
            } else {
                req.setAttribute("message", "修改失败");

                // 删除失败
                req.getRequestDispatcher("fail.jsp").forward(req, resp);
            }

        } catch (IllegalAccessException | InvocationTargetException | UnsupportedEncodingException | SQLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            JdbcUtilsOnDruid.close(connection);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}
