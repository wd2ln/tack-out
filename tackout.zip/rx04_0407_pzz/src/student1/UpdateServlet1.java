package student1;


import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.dbutils.QueryRunner;
import util.JdbcUtilsOnDruid;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;

/**
 * 修改学生信息
 */
@WebServlet("/update1")
public class UpdateServlet1 extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Connection connection=null;
        try {


            // 获取请求参数
            Map<String, String[]> map = req.getParameterMap();
            // 准备实体类对象
            NavInfo1 navInfo1 = new NavInfo1();
            // 将map中的参数封装到实体类对象中
            BeanUtils.populate(navInfo1, map);
            int bh=0;
            switch (navInfo1.getClassName()){
                case "美食":bh=1;break;
                case "甜点饮品":bh=2;break;
                case "超市便利":bh=3;break;
                case "蔬菜水果":bh=4;break;
                case "急救买药":bh=5;break;
            }
            // 获取核心类对象
            QueryRunner queryRunner = new QueryRunner();

            // 获取数据库连接
             connection = JdbcUtilsOnDruid.getConnection();

            // 准备SQL语句
            String sql = "update nav_menu_item nm," +
                    "nav_menu_re_item ni set " +
                    "nm.name=?,ni.menu_id=? " +
                    "where " +
                    " nm.id=ni.item_id and nm.id=?;";

            // 执行SQL语句
            int affectedRows = queryRunner.update(connection, sql,navInfo1.getFoodName(),
                   bh, navInfo1.getId());

            // 判断是否修改成功
            if (affectedRows > 0) {

                req.setAttribute("message", "修改成功");
                // 删除成功
                req.getRequestDispatcher("pageNav1").forward(req, resp);
            } else {
                req.setAttribute("message", "修改失败");

                // 删除失败
                req.getRequestDispatcher("fail.jsp").forward(req, resp);
            }

        } catch (IllegalAccessException | InvocationTargetException | UnsupportedEncodingException | SQLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            JdbcUtilsOnDruid.close(connection);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}
