package student1;

import com.fasterxml.jackson.databind.ObjectMapper;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

/**
 * 验证码生成页
 */
@WebServlet("/code")
public class Code extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {


        // 获取session
        HttpSession session = req.getSession(true);
        // 获取所有的Cookie
        Cookie[] cookies = req.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("code")) {
                    String ss=cookie.getValue();
                    resp.getWriter().write(ss);
                    //resp.getWriter().append("alert('请60s后再试');");
                    return;
                }
            }
        }
        //生成6位验证码
        String cod = Integer.toString((int) ((Math.random() * 9 + 1) * 100000));
        req.setAttribute("codee",cod);
        // 将验证码存放到cookie中，使用cookie来表示验证码的过期时间
        Cookie cookie = new Cookie("code", cod);
        cookie.setMaxAge(60);
        resp.addCookie(cookie);
        session.setAttribute("code", cod);
        session.setMaxInactiveInterval(60);
        req.setAttribute("code",cod);
        // req.getRequestDispatcher("yzm.jsp").forward(req,resp);



        // 发送给前端
        resp.getWriter().print(cod);
    }
}
